<?php

include("dbconfig.php");


if(isset($_POST['save'])){
  // echo "<pre>";
  // print_r($_POST);
  // exit();
  $name = $_POST['fullname'];
  $phoneno = $_POST['phoneno'];
  $email = $_POST['email'];

$sql = "INSERT INTO contactinfo (email, name, ph_number)
VALUES ('$email', '$name','$phoneno');";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
  //echo "<script type='javascript'>alert('New record created successfully')</script>";
  
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
header("Location: contactlist.php");
}
?>
